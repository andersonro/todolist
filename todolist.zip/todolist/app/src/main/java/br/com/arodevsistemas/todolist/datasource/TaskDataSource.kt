package br.com.arodevsistemas.todolist.datasource

import br.com.arodevsistemas.todolist.model.Task

object TaskDataSource {

    private val list = arrayListOf<Task>()

    fun getList() = list

    fun insertTask(task : Task) {
        list.add(task.copy(id = (list.size + 1).toLong()))
    }

}