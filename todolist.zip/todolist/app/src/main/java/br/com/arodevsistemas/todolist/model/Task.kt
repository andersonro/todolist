package br.com.arodevsistemas.todolist.model

data class Task(
    var title : String,
    var description: String,
    var date : String,
    var hour : String,
    var id : Long = 0
)
